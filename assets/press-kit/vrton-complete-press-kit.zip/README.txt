VRTon Press Kit
===============

This ZIP file contains official VRTon promotional materials.

Contents:
- logos/: Official VRTon logos in various formats
- posters/: World and event promotional posters
- stickers/: Stickers and emojis for social platforms

Total files: 10

Usage Guidelines:
✅ Allowed:
- Community content and fan art
- Social media posts about VRTon
- Event promotion and community activities
- Educational content about VRChat

❌ Prohibited:
- Commercial use without permission
- Modification of official logos
- Use in inappropriate or harmful content
- Impersonation of official VRTon accounts

Questions? Contact us through our official Discord server.

Generated: 2025-12-11 10:29:29
